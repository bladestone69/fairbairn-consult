Fairbairn Advice Process, Shareable HTML Package

Contents
- index.html, the branded advice process document

How to use
1. Open index.html in any modern browser to review it locally.
2. To share it as a hosted page, upload index.html to any basic web host or file hosting service that serves HTML.
3. If you want a safer universal attachment for email, export this page to PDF and attach the PDF instead.

Simple hosting options
- Your own website or hosting account
- Netlify Drop
- Cloudflare Pages
- GitHub Pages
- Any internal company web server

Recommended sharing approach
- Best visual result: host index.html and send the link.
- Best compatibility: export to PDF and attach the PDF.
- Best of both: send the PDF plus the hosted link.

Notes
- This package is self-contained and does not depend on external CSS or images.
- If branding or wording changes later, replace index.html and re-upload.
